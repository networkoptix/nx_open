=====================================================================
 vine - Python Promises
=====================================================================

|build-status| |coverage| |license| |wheel| |pyversion| |pyimp|

:Version: 1.1.3
:Web: https://vine.readthedocs.io/
:Download: http://pypi.python.org/pypi/vine/
:Source: http://github.com/celery/vine/
:Keywords: promise, async, future

About
=====


.. |build-status| image:: https://secure.travis-ci.org/celery/vine.png?branch=master
    :alt: Build status
    :target: https://travis-ci.org/celery/vine

.. |coverage| image:: https://codecov.io/github/celery/vine/coverage.svg?branch=master
    :target: https://codecov.io/github/celery/vine?branch=master

.. |license| image:: https://img.shields.io/pypi/l/vine.svg
    :alt: BSD License
    :target: https://opensource.org/licenses/BSD-3-Clause

.. |wheel| image:: https://img.shields.io/pypi/wheel/vine.svg
    :alt: Vine can be installed via wheel
    :target: http://pypi.python.org/pypi/vine/

.. |pyversion| image:: https://img.shields.io/pypi/pyversions/vine.svg
    :alt: Supported Python versions.
    :target: http://pypi.python.org/pypi/vine/

.. |pyimp| image:: https://img.shields.io/pypi/implementation/vine.svg
    :alt: Support Python implementations.
    :target: http://pypi.python.org/pypi/vine/



