This is the standalone email package.  This is a copy of what's available in
Python but you may want to use the standalone version if you want the latest
and greatest email package, even in older Pythons.

