A configurable HTML Minifier with safety features.

.. image:: https://travis-ci.org/mankyd/htmlmin.png?branch=master
   :target: http://travis-ci.org/mankyd/htmlmin

Documentation: https://htmlmin.readthedocs.org/en/latest/


